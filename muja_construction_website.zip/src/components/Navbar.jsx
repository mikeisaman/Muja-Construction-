import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <header className="bg-blue-600 text-white shadow-md">
      <div className="container mx-auto flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          <img src="/assets/logo-house-grey.svg" alt="Muja Construction Logo" className="h-8 w-8" />
          <span className="text-lg font-bold">Muja Construction</span>
        </div>
        <nav className="space-x-4 hidden md:block">
          <Link to="/" className="hover:underline">Home</Link>
          <Link to="/about" className="hover:underline">About</Link>
          <Link to="/services" className="hover:underline">Services</Link>
          <Link to="/projects" className="hover:underline">Projects</Link>
          <Link to="/contact" className="hover:underline">Contact</Link>
          <Link to="/careers" className="hover:underline">Careers</Link>
          <Link to="/testimonials" className="hover:underline">Testimonials</Link>
          <Link to="/blog" className="hover:underline">Blog</Link>
          <Link to="/faq" className="hover:underline">FAQ</Link>
        </nav>
      </div>
    </header>
  );
}
