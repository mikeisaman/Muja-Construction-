export default function Footer() {
  return (
    <footer className="bg-gray-700 text-white py-6">
      <div className="container mx-auto px-4 text-center">
        <p className="text-sm">&copy; {new Date().getFullYear()} Muja Construction. All rights reserved.</p>
        <p className="text-xs mt-1">Built with React & Tailwind CSS</p>
        <div className="mt-2 space-y-1 text-sm">
          <p>📞 +27 878 126 9365</p>
          <p>📞 +263 77 193 4255</p>
          <p>📞 +27 74 246 6687</p>
        </div>
      </div>
    </footer>
  );
}
