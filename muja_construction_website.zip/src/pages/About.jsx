export default function About() { return <div className='container mx-auto p-8'>About Page - Coming Soon</div>; }
