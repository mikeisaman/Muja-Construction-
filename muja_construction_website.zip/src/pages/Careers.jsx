export default function Careers() { return <div className='container mx-auto p-8'>Careers Page - Coming Soon</div>; }
