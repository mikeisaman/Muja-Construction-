export default function FAQ() { return <div className='container mx-auto p-8'>FAQ Page - Coming Soon</div>; }
