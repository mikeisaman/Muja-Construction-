export default function Contact() { return <div className='container mx-auto p-8'>Contact Page - Coming Soon</div>; }
