export default function Blog() { return <div className='container mx-auto p-8'>Blog Page - Coming Soon</div>; }
