export default function Testimonials() { return <div className='container mx-auto p-8'>Testimonials Page - Coming Soon</div>; }
