import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <section>
      <div
        className="bg-cover bg-center bg-no-repeat min-h-[60vh] flex items-center justify-center text-center px-4"
        style={{ backgroundImage: "url('/assets/construction-bg.jpg')" }}
      >
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="bg-white/80 p-8 rounded-xl shadow-xl"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-blue-600 mb-4">Welcome to Muja Construction</h1>
          <p className="text-gray-800 text-lg mb-6">
            Building strong foundations for a better tomorrow. We specialize in residential, commercial,
            and industrial construction services.
          </p>
          <Link
            to="/services"
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-full transition"
          >
            View Our Services
          </Link>
        </motion.div>
      </div>

      <motion.div
        className="bg-gray-100 py-16"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 1 }}
      >
        <div className="container mx-auto px-4 grid md:grid-cols-3 gap-8 text-center">
          <motion.div whileHover={{ scale: 1.05 }}>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Experienced Team</h3>
            <p className="text-gray-600">Decades of expertise in construction and project management.</p>
          </motion.div>
          <motion.div whileHover={{ scale: 1.05 }}>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Quality Materials</h3>
            <p className="text-gray-600">We use only top-tier, durable materials for long-lasting results.</p>
          </motion.div>
          <motion.div whileHover={{ scale: 1.05 }}>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Timely Delivery</h3>
            <p className="text-gray-600">Projects are completed on time and within budget, always.</p>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
}
