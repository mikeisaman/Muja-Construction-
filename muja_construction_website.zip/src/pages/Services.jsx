export default function Services() { return <div className='container mx-auto p-8'>Services Page - Coming Soon</div>; }
