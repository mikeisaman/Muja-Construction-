export default function Projects() { return <div className='container mx-auto p-8'>Projects Page - Coming Soon</div>; }
